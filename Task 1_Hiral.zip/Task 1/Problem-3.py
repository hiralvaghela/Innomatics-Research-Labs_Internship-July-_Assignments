if __name__ == '__main__':
    a = int(input())
    b = int(input())
    
    sum = a + b
    print(sum)
    
    div = a - b
    print(div)
    
    product = a * b
    print(product)
