if __name__ == '__main__':
    a = int(input())
    b = int(input())
    
    div_1  = a//b
    print(div_1)
    
    div_2 = a/b
    print(div_2)
